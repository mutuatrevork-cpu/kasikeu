use crate::{Result, auth};
use sqlx::SqlitePool;

pub async fn bootstrap(
    db: &SqlitePool,
    demo: bool,
    admin_password: &str,
    demo_password: Option<&str>,
) -> Result<()> {
    let mut tx = db.begin().await?;
    let existing: i64 = sqlx::query_scalar("SELECT count(*) FROM accounts")
        .fetch_one(&mut *tx)
        .await?;
    if existing > 0 {
        return Ok(());
    }
    let admin_login = if demo {
        "admin@example.test".to_owned()
    } else {
        std::env::var("PORTAL_ADMIN_LOGIN")
            .map_err(|_| crate::Error::Invalid("Set PORTAL_ADMIN_LOGIN."))?
    };
    sqlx::query("INSERT INTO accounts (id,role,login,name,password_hash) VALUES (1,'admin',?, 'School Administrator',?)")
        .bind(admin_login)
        .bind(auth::hash(admin_password)?).execute(&mut *tx).await?;
    if let Some(password) = demo_password.filter(|_| demo) {
        let hash = auth::hash(password)?;
        sqlx::query("INSERT INTO accounts (id,role,login,name,password_hash,tsc_verified,posting_verified) VALUES
           (2,'student','DEMO-001','Demo Student One',?,0,0),
           (3,'student','DEMO-002','Demo Student Two',?,0,0),
           (4,'guardian','guardian@example.test','Demo Guardian',?,0,0),
           (5,'teacher','teacher@example.test','Demo Teacher',?,1,1),
           (6,'support','bursar@example.test','Demo Bursar',?,0,0)")
           .bind(&hash).bind(&hash).bind(&hash).bind(&hash).bind(&hash)
           .execute(&mut *tx).await?;
        sqlx::raw_sql(include_str!("demo.sql"))
            .execute(&mut *tx)
            .await?;
    }
    tx.commit().await?;
    Ok(())
}
