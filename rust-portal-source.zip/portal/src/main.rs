mod auth;
mod imports;
mod records;
mod seed;

use askama::Template;
use axum::{
    Router,
    extract::{DefaultBodyLimit, Query, State},
    http::{HeaderValue, Method, StatusCode, header},
    response::{Html, IntoResponse, Redirect, Response},
    routing::{get, post},
};
use serde::Deserialize;
use sqlx::{
    SqlitePool,
    sqlite::{SqliteConnectOptions, SqliteJournalMode, SqlitePoolOptions},
};
use std::{sync::Arc, time::Duration};
use tokio::sync::Semaphore;
use tower_http::{
    cors::{AllowOrigin, CorsLayer},
    set_header::SetResponseHeaderLayer,
};
use tower_sessions::{Expiry, Session, SessionManagerLayer, cookie::SameSite};
use tower_sessions_sqlx_store::SqliteStore;

type Result<T> = std::result::Result<T, Error>;
#[derive(Debug)]
enum Error {
    Login,
    Forbidden,
    NotFound,
    Invalid(&'static str),
    Status(StatusCode, &'static str),
    Internal,
}
impl From<sqlx::Error> for Error {
    fn from(e: sqlx::Error) -> Self {
        eprintln!(
            "Database operation failed: {}",
            e.as_database_error()
                .map_or("connection or query error".into(), |code| code
                    .code()
                    .unwrap_or_default())
        );
        Self::Internal
    }
}
impl From<tower_sessions::session::Error> for Error {
    fn from(_: tower_sessions::session::Error) -> Self {
        Self::Internal
    }
}
impl IntoResponse for Error {
    fn into_response(self) -> Response {
        match self {
            Self::Login => Redirect::to("/login").into_response(),
            Self::Forbidden => (
                StatusCode::FORBIDDEN,
                "This account does not have permission.",
            )
                .into_response(),
            Self::NotFound => (StatusCode::NOT_FOUND, "Record unavailable.").into_response(),
            Self::Invalid(message) => (StatusCode::BAD_REQUEST, message).into_response(),
            Self::Status(status, message) => (status, message).into_response(),
            Self::Internal => (
                StatusCode::INTERNAL_SERVER_ERROR,
                "The portal could not complete this request.",
            )
                .into_response(),
        }
    }
}

#[derive(Clone)]
struct App {
    db: SqlitePool,
    demo: bool,
    dummy_hash: String,
    password_slots: Arc<Semaphore>,
}

#[derive(Template)]
#[template(path = "login.html")]
struct LoginPage {
    csrf: String,
    role: String,
    demo: bool,
}
#[derive(Deserialize)]
struct LoginQuery {
    role: Option<String>,
}
async fn login_page(
    State(app): State<App>,
    session: Session,
    Query(query): Query<LoginQuery>,
) -> Result<Html<String>> {
    let role = query
        .role
        .filter(|role| {
            ["student", "guardian", "teacher", "support", "admin"].contains(&role.as_str())
        })
        .unwrap_or("student".to_owned());
    page(LoginPage {
        csrf: auth::csrf(&session).await?,
        role,
        demo: app.demo,
    })
}
fn page(template: impl Template) -> Result<Html<String>> {
    Ok(Html(template.render().map_err(|_| Error::Internal)?))
}
async fn health(State(app): State<App>) -> Result<&'static str> {
    sqlx::query("SELECT 1").execute(&app.db).await?;
    Ok("OK")
}
async fn css() -> impl IntoResponse {
    (
        [(header::CONTENT_TYPE, "text/css; charset=utf-8")],
        include_str!("../templates/portal.css"),
    )
}

async fn database(options: SqliteConnectOptions) -> Result<SqlitePool> {
    let db = SqlitePoolOptions::new()
        .max_connections(5)
        .connect_with(options)
        .await?;
    sqlx::migrate!().run(&db).await.map_err(|e| {
        eprintln!("Migration failed: {e}");
        Error::Internal
    })?;
    Ok(db)
}

async fn app_router(
    app: App,
    secure: bool,
    origin: HeaderValue,
    allow_local: bool,
) -> Result<Router> {
    let store = SqliteStore::new(app.db.clone());
    store.migrate().await?;
    let sessions = SessionManagerLayer::new(store)
        .with_secure(secure)
        .with_http_only(true)
        .with_name(if secure {
            "__Host-kasikeu"
        } else {
            "kasikeu-local"
        })
        .with_same_site(SameSite::Lax)
        .with_expiry(Expiry::OnInactivity(time::Duration::minutes(30)));
    let cors = CorsLayer::new()
        .allow_methods([Method::GET])
        .allow_origin(AllowOrigin::predicate(move |candidate, _| {
            if *candidate == origin {
                return true;
            }
            allow_local
                && candidate
                    .to_str()
                    .ok()
                    .and_then(|value| value.strip_prefix("http://localhost:"))
                    .is_some_and(|port| port.parse::<u16>().is_ok())
        }));
    let public = Router::new()
        .route("/notice", get(records::public_notice))
        .route("/documents", get(records::public_documents))
        .route("/documents/{id}", get(records::download))
        .layer(cors);
    let private = Router::new()
        .route("/", get(|| async { Redirect::to("/login") }))
        .route("/login", get(login_page).post(auth::login))
        .route("/logout", post(auth::logout))
        .route("/dashboard", get(records::dashboard))
        .route("/admin", get(records::admin))
        .route("/admin/notice", post(records::save_notice))
        .route("/admin/marks/preview", post(imports::preview))
        .route("/admin/marks/confirm", post(imports::confirm))
        .route("/admin/documents", post(records::upload))
        .route(
            "/admin/documents/{id}/remove",
            post(records::remove_document),
        )
        .route("/dashboard/fees", post(records::save_fee))
        .route("/dashboard/discipline", post(records::save_discipline))
        .layer(SetResponseHeaderLayer::overriding(
            header::CACHE_CONTROL,
            HeaderValue::from_static("no-store"),
        ))
        .layer(sessions);
    Ok(private.merge(Router::new().route("/health", get(health)).route("/portal.css",get(css)))
        .nest("/api/public", public)
        .layer(DefaultBodyLimit::max(2 * 1024 * 1024 + 8192))
        .layer(SetResponseHeaderLayer::overriding(header::X_CONTENT_TYPE_OPTIONS,HeaderValue::from_static("nosniff")))
        .layer(SetResponseHeaderLayer::overriding(header::CONTENT_SECURITY_POLICY,
            HeaderValue::from_static("default-src 'none'; style-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")))
        .layer(SetResponseHeaderLayer::overriding(header::REFERRER_POLICY,HeaderValue::from_static("no-referrer")))
        .with_state(app))
}

fn env_password(key: &str) -> std::result::Result<String, Box<dyn std::error::Error>> {
    let password = std::env::var(key)?;
    if !(16..=256).contains(&password.len()) {
        return Err(format!("{key} must be 16–256 bytes").into());
    }
    Ok(password)
}

#[tokio::main]
async fn main() -> std::result::Result<(), Box<dyn std::error::Error>> {
    let demo = std::env::var("PORTAL_DEMO").as_deref() == Ok("1");
    let local = std::env::var("PORTAL_LOCAL_HTTP").as_deref() == Ok("1");
    if local && (!demo || std::env::var_os("RENDER").is_some()) {
        return Err("Local HTTP is available only for the loopback demo.".into());
    }
    let admin_password = env_password("PORTAL_ADMIN_PASSWORD")?;
    let demo_password = demo
        .then(|| env_password("PORTAL_DEMO_PASSWORD"))
        .transpose()?;
    if demo_password.as_ref() == Some(&admin_password) {
        return Err("Use separate admin and demo passwords.".into());
    }
    let root = std::env::var("PORTAL_DATA_DIR").unwrap_or_else(|_| "data".to_owned());
    std::fs::create_dir_all(&root)?;
    let options = SqliteConnectOptions::new()
        .filename(std::path::Path::new(&root).join(if demo {
            "demo.sqlite"
        } else {
            "portal.sqlite"
        }))
        .create_if_missing(true)
        .foreign_keys(true)
        .journal_mode(SqliteJournalMode::Wal)
        .busy_timeout(Duration::from_secs(5));
    let db = database(options).await.map_err(|e| format!("{e:?}"))?;
    seed::bootstrap(&db, demo, &admin_password, demo_password.as_deref())
        .await
        .map_err(|e| format!("{e:?}"))?;
    let app = App {
        db,
        demo,
        dummy_hash: auth::hash(&uuid::Uuid::new_v4().to_string()).map_err(|e| format!("{e:?}"))?,
        password_slots: Arc::new(Semaphore::new(2)),
    };
    let origin = std::env::var("PUBLIC_SITE_ORIGIN")
        .unwrap_or_else(|_| "https://kasikeu.vercel.app".into())
        .parse()?;
    let router = app_router(app, !local, origin, local)
        .await
        .map_err(|e| format!("{e:?}"))?;
    let host = if local { "127.0.0.1" } else { "0.0.0.0" };
    let port: u16 = std::env::var("PORT")
        .unwrap_or_else(|_| "8080".into())
        .parse()?;
    let listener = tokio::net::TcpListener::bind((host, port)).await?;
    eprintln!("Kasikeu portal listening on {host}:{port}");
    axum::serve(listener, router).await?;
    Ok(())
}

#[cfg(test)]
mod tests;
