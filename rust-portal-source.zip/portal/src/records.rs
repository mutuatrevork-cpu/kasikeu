use askama::Template;
use axum::{
    Form, Json,
    extract::{Multipart, Path, Query, State},
    http::{StatusCode, header},
    response::{Html, IntoResponse, Redirect},
};
use serde::{Deserialize, Serialize};
use tower_sessions::Session;

use crate::{
    App, Error, Result,
    auth::{CsrfForm, User, check_csrf, csrf},
    page,
};

#[derive(Serialize, sqlx::FromRow)]
pub struct Notice {
    title: String,
    reporting_date: String,
    arrival_window: String,
    message: String,
    document_id: Option<i64>,
    updated_at: String,
}

#[derive(Serialize, sqlx::FromRow)]
pub struct Document {
    id: i64,
    title: String,
    category: String,
    created_at: String,
}

async fn notice(app: &App) -> Result<Option<Notice>> {
    Ok(sqlx::query_as!(Notice, "SELECT title, reporting_date, arrival_window, message, document_id, updated_at FROM notice WHERE id=1")
        .fetch_optional(&app.db).await?)
}
async fn documents(app: &App) -> Result<Vec<Document>> {
    Ok(sqlx::query_as!(
        Document,
        "SELECT id, title, category, created_at FROM documents ORDER BY id DESC"
    )
    .fetch_all(&app.db)
    .await?)
}
#[derive(Serialize)]
pub struct Public<T> {
    demo: bool,
    data: T,
}
pub async fn public_notice(State(app): State<App>) -> Result<Json<Public<Option<Notice>>>> {
    Ok(Json(Public {
        demo: app.demo,
        data: notice(&app).await?,
    }))
}
pub async fn public_documents(State(app): State<App>) -> Result<Json<Public<Vec<Document>>>> {
    Ok(Json(Public {
        demo: app.demo,
        data: documents(&app).await?,
    }))
}
pub async fn download(State(app): State<App>, Path(id): Path<i64>) -> Result<impl IntoResponse> {
    let pdf: Vec<u8> = sqlx::query_scalar!("SELECT pdf FROM documents WHERE id=?", id)
        .fetch_optional(&app.db)
        .await?
        .ok_or(Error::NotFound)?;
    Ok((
        [
            (header::CONTENT_TYPE, "application/pdf"),
            (
                header::CONTENT_DISPOSITION,
                "attachment; filename=\"kasikeu-document.pdf\"",
            ),
            (header::CACHE_CONTROL, "no-store"),
        ],
        pdf,
    ))
}

#[derive(Template)]
#[template(path = "admin.html")]
struct AdminPage {
    csrf: String,
    demo: bool,
    title: String,
    reporting_date: String,
    arrival_window: String,
    message: String,
    selected_document: i64,
    documents: Vec<Document>,
}
pub async fn admin(State(app): State<App>, user: User, session: Session) -> Result<Html<String>> {
    user.admin()?;
    let active = notice(&app).await?;
    let (title, reporting_date, arrival_window, message, selected_document) = active
        .map(|n| {
            (
                n.title,
                n.reporting_date,
                n.arrival_window,
                n.message,
                n.document_id.unwrap_or_default(),
            )
        })
        .unwrap_or_default();
    page(AdminPage {
        csrf: csrf(&session).await?,
        demo: app.demo,
        title,
        reporting_date,
        arrival_window,
        message,
        selected_document,
        documents: documents(&app).await?,
    })
}

#[derive(Deserialize)]
pub struct NoticeForm {
    csrf: String,
    title: String,
    reporting_date: String,
    arrival_window: String,
    message: String,
    document_id: i64,
}
pub async fn save_notice(
    State(app): State<App>,
    user: User,
    session: Session,
    Form(form): Form<NoticeForm>,
) -> Result<Redirect> {
    user.admin()?;
    check_csrf(&session, &form.csrf).await?;
    let title = required(&form.title, 120)?;
    let arrival = required(&form.arrival_window, 100)?;
    let message = required(&form.message, 600)?;
    let date = form.reporting_date.split('-').collect::<Vec<_>>();
    let valid = match date.as_slice() {
        [year, month, day] if year.len() == 4 && month.len() == 2 && day.len() == 2 => {
            let parsed = || -> Option<time::Date> {
                time::Date::from_calendar_date(
                    year.parse().ok()?,
                    time::Month::try_from(month.parse::<u8>().ok()?).ok()?,
                    day.parse().ok()?,
                )
                .ok()
            };
            parsed().is_some()
        }
        _ => false,
    };
    if !valid {
        return Err(Error::Invalid("Enter a valid reporting date."));
    }
    let mut tx = app.db.begin_with("BEGIN IMMEDIATE").await?;
    let document = match form.document_id {
        0 => None,
        id => {
            sqlx::query_scalar::<_, i64>(
                "SELECT id FROM documents WHERE id=? AND category='joining'",
            )
            .bind(id)
            .fetch_optional(&mut *tx)
            .await?
            .ok_or(Error::Invalid("Choose a joining instructions PDF."))?;
            Some(id)
        }
    };
    sqlx::query("INSERT INTO notice (id,title,reporting_date,arrival_window,message,document_id) VALUES (1,?,?,?,?,?)
        ON CONFLICT(id) DO UPDATE SET title=excluded.title, reporting_date=excluded.reporting_date,
        arrival_window=excluded.arrival_window,message=excluded.message,document_id=excluded.document_id,updated_at=CURRENT_TIMESTAMP")
        .bind(title).bind(&form.reporting_date).bind(arrival).bind(message).bind(document).execute(&mut *tx).await?;
    audit(&mut tx, user.id, "publish_notice", 1).await?;
    tx.commit().await?;
    Ok(Redirect::to("/admin"))
}

fn required(value: &str, max: usize) -> Result<&str> {
    let text = value.trim();
    if text.is_empty() || text.chars().count() > max || text.contains('\0') {
        return Err(Error::Invalid(
            "A required field is blank or exceeds its limit.",
        ));
    }
    Ok(text)
}

pub async fn upload(
    State(app): State<App>,
    user: User,
    session: Session,
    mut form: Multipart,
) -> Result<Redirect> {
    user.admin()?;
    let mut evidence = None;
    let mut title = None;
    let mut category = None;
    let mut pdf = None;
    while let Some(field) = form
        .next_field()
        .await
        .map_err(|_| Error::Invalid("Invalid upload."))?
    {
        match field.name() {
            Some("csrf") if evidence.is_none() => {
                evidence = Some(
                    field
                        .text()
                        .await
                        .map_err(|_| Error::Invalid("Invalid form."))?,
                )
            }
            Some("title") if title.is_none() => {
                title = Some(
                    field
                        .text()
                        .await
                        .map_err(|_| Error::Invalid("Invalid title."))?,
                )
            }
            Some("category") if category.is_none() => {
                category = Some(
                    field
                        .text()
                        .await
                        .map_err(|_| Error::Invalid("Invalid category."))?,
                )
            }
            Some("pdf") if pdf.is_none() => {
                let bytes = field
                    .bytes()
                    .await
                    .map_err(|_| Error::Invalid("Invalid PDF upload."))?;
                if bytes.len() > 2 * 1024 * 1024
                    || !bytes.starts_with(b"%PDF-")
                    || !bytes
                        .iter()
                        .rev()
                        .copied()
                        .skip_while(u8::is_ascii_whitespace)
                        .take(5)
                        .eq(b"FOE%%".iter().copied())
                {
                    return Err(Error::Invalid("Choose a PDF of at most 2 MiB."));
                }
                pdf = Some(bytes);
            }
            _ => return Err(Error::Invalid("Unexpected upload field.")),
        }
    }
    check_csrf(&session, evidence.as_deref().unwrap_or_default()).await?;
    let title = required(title.as_deref().unwrap_or_default(), 120)?;
    let category = category
        .filter(|category| {
            ["joining", "fees", "checklist", "learning"].contains(&category.as_str())
        })
        .ok_or(Error::Invalid("Choose a document category."))?;
    let pdf = pdf.ok_or(Error::Invalid("Choose a PDF."))?;
    let mut tx = app.db.begin_with("BEGIN IMMEDIATE").await?;
    let id = sqlx::query("INSERT INTO documents (title,category,pdf) SELECT ?,?,? WHERE (SELECT count(*) FROM documents)<20")
        .bind(title).bind(category).bind(pdf.as_ref()).execute(&mut *tx).await?;
    if id.rows_affected() == 0 {
        return Err(Error::Status(
            StatusCode::CONFLICT,
            "Remove an older document before publishing another.",
        ));
    }
    audit(&mut tx, user.id, "publish_document", id.last_insert_rowid()).await?;
    tx.commit().await?;
    Ok(Redirect::to("/admin"))
}
pub async fn remove_document(
    State(app): State<App>,
    user: User,
    session: Session,
    Path(id): Path<i64>,
    Form(form): Form<CsrfForm>,
) -> Result<Redirect> {
    user.admin()?;
    check_csrf(&session, &form.csrf).await?;
    let mut tx = app.db.begin_with("BEGIN IMMEDIATE").await?;
    sqlx::query(
        "UPDATE notice SET document_id=NULL, updated_at=CURRENT_TIMESTAMP WHERE document_id=?",
    )
    .bind(id)
    .execute(&mut *tx)
    .await?;
    if sqlx::query("DELETE FROM documents WHERE id=?")
        .bind(id)
        .execute(&mut *tx)
        .await?
        .rows_affected()
        == 0
    {
        return Err(Error::NotFound);
    }
    audit(&mut tx, user.id, "remove_document", id).await?;
    tx.commit().await?;
    Ok(Redirect::to("/admin"))
}
pub(crate) async fn audit(
    tx: &mut sqlx::Transaction<'_, sqlx::Sqlite>,
    actor: i64,
    action: &str,
    target: i64,
) -> Result<()> {
    sqlx::query("INSERT INTO audit(actor,action,target) VALUES (?,?,?)")
        .bind(actor)
        .bind(action)
        .bind(target)
        .execute(&mut **tx)
        .await?;
    Ok(())
}

#[derive(sqlx::FromRow)]
struct Student {
    id: i64,
    name: String,
    admission: String,
    class: String,
}
#[derive(sqlx::FromRow)]
struct Mark {
    assessment: String,
    subject: String,
    score: i64,
    maximum: i64,
    source: String,
    updated_at: String,
}
#[derive(sqlx::FromRow)]
struct Fee {
    description: String,
    amount_cents: i64,
    reference: String,
    created_at: String,
}
#[derive(sqlx::FromRow)]
struct Incident {
    summary: String,
    internal_note: String,
    shared: bool,
    created_at: String,
}

fn kes(cents: &i64) -> String {
    let whole = cents.unsigned_abs() / 100;
    let fraction = cents.unsigned_abs() % 100;
    format!(
        "{}KES {whole}.{fraction:02}",
        if *cents < 0 { "−" } else { "" }
    )
}
impl Fee {
    fn amount(&self) -> String {
        kes(&self.amount_cents)
    }
}

#[derive(Deserialize)]
pub struct StudentQuery {
    student: Option<i64>,
}
#[derive(Template)]
#[template(path = "dashboard.html")]
struct Dashboard {
    csrf: String,
    demo: bool,
    user: User,
    students: Vec<Student>,
    current: Option<Student>,
    marks: Vec<Mark>,
    fees: Vec<Fee>,
    balance: String,
    incidents: Vec<Incident>,
    read_marks: bool,
    read_fees: bool,
    read_discipline: bool,
    edit_fees: bool,
    edit_discipline: bool,
}
async fn permission(app: &App, user: &User, permission: &str) -> Result<bool> {
    Ok(user.role == "admin" || (user.role == "support" && sqlx::query_scalar::<_, bool>(
        "SELECT EXISTS(SELECT 1 FROM support_permissions WHERE account_id=? AND permission=?)")
        .bind(user.id).bind(permission).fetch_one(&app.db).await?))
}
pub async fn dashboard(
    State(app): State<App>,
    user: User,
    session: Session,
    Query(query): Query<StudentQuery>,
) -> Result<Html<String>> {
    let edit_fees = permission(&app, &user, "fees").await?;
    let edit_discipline = permission(&app, &user, "discipline").await?;
    let read_marks = user.role != "support";
    let read_fees = read_marks || edit_fees;
    let read_discipline = read_marks || edit_discipline;
    let students = sqlx::query_as::<_, Student>(
        "SELECT id,name,admission,class FROM students s WHERE
         ? OR (s.account_id=? AND ?='student')
         OR (?='guardian' AND EXISTS(SELECT 1 FROM guardian_links WHERE student_id=s.id AND account_id=?))
         OR (?='teacher' AND EXISTS(SELECT 1 FROM teacher_assignments WHERE student_id=s.id AND account_id=?))
         ORDER BY name,id")
        .bind(edit_fees || edit_discipline).bind(user.id).bind(&user.role).bind(&user.role).bind(user.id)
        .bind(&user.role).bind(user.id).fetch_all(&app.db).await?;
    if query
        .student
        .is_some_and(|id| !students.iter().any(|student| student.id == id))
    {
        return Err(Error::NotFound);
    }
    let current = query
        .student
        .or_else(|| students.first().map(|student| student.id));
    let mut marks = Vec::new();
    let mut fees: Vec<Fee> = Vec::new();
    let mut incidents = Vec::new();
    if let Some(id) = current {
        if read_marks {
            marks = sqlx::query_as("SELECT assessment,subject,score,maximum,source,updated_at FROM marks WHERE student_id=? AND released=1 ORDER BY assessment,subject").bind(id).fetch_all(&app.db).await?;
        }
        if read_fees {
            fees = sqlx::query_as("SELECT description,amount_cents,reference,created_at FROM fee_entries WHERE student_id=? ORDER BY id").bind(id).fetch_all(&app.db).await?;
        }
        if read_discipline {
            incidents = sqlx::query_as("SELECT summary,CASE WHEN ? THEN internal_note ELSE '' END AS internal_note,shared,created_at FROM discipline WHERE student_id=? AND (shared=1 OR ?) ORDER BY id DESC")
                .bind(edit_discipline).bind(id).bind(edit_discipline).fetch_all(&app.db).await?;
        }
    }
    let balance = kes(&fees.iter().map(|fee| fee.amount_cents).sum());
    let current = current
        .and_then(|id| students.iter().find(|s| s.id == id))
        .map(|s| Student {
            id: s.id,
            name: s.name.clone(),
            admission: s.admission.clone(),
            class: s.class.clone(),
        });
    page(Dashboard {
        csrf: csrf(&session).await?,
        demo: app.demo,
        user,
        students,
        current,
        marks,
        fees,
        balance,
        incidents,
        read_marks,
        read_fees,
        read_discipline,
        edit_fees,
        edit_discipline,
    })
}
#[derive(Deserialize)]
pub struct FeeForm {
    student: i64,
    csrf: String,
    description: String,
    amount_cents: i64,
    reference: String,
}
pub async fn save_fee(
    State(app): State<App>,
    user: User,
    session: Session,
    Form(form): Form<FeeForm>,
) -> Result<Redirect> {
    if !permission(&app, &user, "fees").await? {
        return Err(Error::Forbidden);
    }
    check_csrf(&session, &form.csrf).await?;
    let description = required(&form.description, 120)?;
    let reference = required(&form.reference, 80)?;
    if form.amount_cents == 0 || form.amount_cents.unsigned_abs() > 100_000_000 {
        return Err(Error::Invalid("Enter a signed amount up to KES 1,000,000."));
    }
    let mut tx = app.db.begin_with("BEGIN IMMEDIATE").await?;
    let inserted = sqlx::query(
        "INSERT INTO fee_entries(student_id,description,amount_cents,reference)
        SELECT id,?,?,? FROM students WHERE id=? ON CONFLICT(reference) DO NOTHING",
    )
    .bind(description)
    .bind(form.amount_cents)
    .bind(reference)
    .bind(form.student)
    .execute(&mut *tx)
    .await?;
    if inserted.rows_affected() == 0 {
        return Err(Error::Status(
            StatusCode::CONFLICT,
            "Student unavailable or transaction reference already used.",
        ));
    }
    audit(&mut tx, user.id, "record_fee", inserted.last_insert_rowid()).await?;
    tx.commit().await?;
    Ok(Redirect::to(&format!(
        "/dashboard?student={}",
        form.student
    )))
}

#[derive(Deserialize)]
pub struct DisciplineForm {
    student: i64,
    csrf: String,
    summary: String,
    internal_note: String,
    shared: Option<String>,
}
pub async fn save_discipline(
    State(app): State<App>,
    user: User,
    session: Session,
    Form(form): Form<DisciplineForm>,
) -> Result<Redirect> {
    if !permission(&app, &user, "discipline").await? {
        return Err(Error::Forbidden);
    }
    check_csrf(&session, &form.csrf).await?;
    let summary = required(&form.summary, 400)?;
    if form.internal_note.chars().count() > 1000 {
        return Err(Error::Invalid("The private note exceeds its limit."));
    }
    let mut tx = app.db.begin_with("BEGIN IMMEDIATE").await?;
    let inserted = sqlx::query("INSERT INTO discipline(student_id,summary,internal_note,shared) SELECT id,?,?,? FROM students WHERE id=?")
        .bind(summary).bind(form.internal_note.trim()).bind(form.shared.as_deref()==Some("on")).bind(form.student).execute(&mut *tx).await?;
    if inserted.rows_affected() == 0 {
        return Err(Error::NotFound);
    }
    audit(
        &mut tx,
        user.id,
        "record_discipline",
        inserted.last_insert_rowid(),
    )
    .await?;
    tx.commit().await?;
    Ok(Redirect::to(&format!(
        "/dashboard?student={}",
        form.student
    )))
}
