use argon2::{Argon2, PasswordHash, PasswordHasher, PasswordVerifier, password_hash::SaltString};
use axum::{
    Form,
    extract::{FromRequestParts, State},
    http::{StatusCode, request::Parts},
    response::Redirect,
};
use serde::Deserialize;
use tower_sessions::Session;
use uuid::Uuid;

use crate::{App, Error, Result};

#[derive(Clone, sqlx::FromRow)]
pub struct User {
    pub id: i64,
    pub role: String,
    pub name: String,
}

impl FromRequestParts<App> for User {
    type Rejection = Error;

    async fn from_request_parts(parts: &mut Parts, state: &App) -> Result<Self> {
        let session = Session::from_request_parts(parts, state)
            .await
            .map_err(|_| Error::Internal)?;
        let id: i64 = session.get("account").await?.ok_or(Error::Login)?;
        sqlx::query_as::<_, Self>(
            "SELECT id, role, name FROM accounts WHERE id=? AND active=1
             AND (role!='teacher' OR (tsc_verified=1 AND posting_verified=1))",
        )
        .bind(id)
        .fetch_optional(&state.db)
        .await?
        .ok_or(Error::Login)
    }
}

impl User {
    pub fn admin(&self) -> Result<()> {
        if self.role == "admin" {
            Ok(())
        } else {
            Err(Error::Forbidden)
        }
    }
}

pub async fn csrf(session: &Session) -> Result<String> {
    if let Some(value) = session.get("csrf").await? {
        return Ok(value);
    }
    let value = Uuid::new_v4().simple().to_string();
    session.insert("csrf", &value).await?;
    Ok(value)
}

pub async fn check_csrf(session: &Session, submitted: &str) -> Result<()> {
    match session.get::<String>("csrf").await? {
        Some(expected) if expected == submitted => Ok(()),
        _ => Err(Error::Forbidden),
    }
}

pub fn hash(password: &str) -> Result<String> {
    let salt = SaltString::encode_b64(Uuid::new_v4().as_bytes()).map_err(|_| Error::Internal)?;
    Ok(Argon2::default()
        .hash_password(password.as_bytes(), &salt)
        .map_err(|_| Error::Internal)?
        .to_string())
}

#[derive(Deserialize)]
pub struct LoginForm {
    role: String,
    login: String,
    password: String,
    csrf: String,
}

pub async fn login(
    State(app): State<App>,
    session: Session,
    Form(form): Form<LoginForm>,
) -> Result<Redirect> {
    check_csrf(&session, &form.csrf).await?;
    if form.login.len() > 254 || form.password.len() > 256 {
        return Err(Error::Invalid("Check the sign-in details."));
    }
    // Limit expensive work even when several visitors submit at once.
    let permit = app
        .password_slots
        .clone()
        .try_acquire_owned()
        .map_err(|_| {
            Error::Status(
                StatusCode::TOO_MANY_REQUESTS,
                "Try signing in again shortly.",
            )
        })?;
    let row = sqlx::query_as::<_, (i64, String, bool)>(
        "SELECT id, password_hash, active=1 AND (role!='teacher' OR
         (tsc_verified=1 AND posting_verified=1)) FROM accounts WHERE role=? AND login=?",
    )
    .bind(&form.role)
    .bind(form.login.trim())
    .fetch_optional(&app.db)
    .await?;
    let (id, hash, active) = row.unwrap_or((0, app.dummy_hash.clone(), false));
    let password = form.password;
    let valid = tokio::task::spawn_blocking(move || {
        let _permit = permit;
        PasswordHash::new(&hash).ok().is_some_and(|hash| {
            Argon2::default()
                .verify_password(password.as_bytes(), &hash)
                .is_ok()
        })
    })
    .await
    .map_err(|_| Error::Internal)?;
    if !(active && valid) {
        return Err(Error::Status(
            StatusCode::UNAUTHORIZED,
            "Check the account type and sign-in details.",
        ));
    }
    session.cycle_id().await?;
    session.remove::<String>("csrf").await?;
    session.insert("account", id).await?;
    Ok(Redirect::to(if form.role == "admin" {
        "/admin"
    } else {
        "/dashboard"
    }))
}

#[derive(Deserialize)]
pub struct CsrfForm {
    pub csrf: String,
}

pub async fn logout(session: Session, Form(form): Form<CsrfForm>) -> Result<Redirect> {
    check_csrf(&session, &form.csrf).await?;
    session.flush().await?;
    Ok(Redirect::to("/login"))
}
