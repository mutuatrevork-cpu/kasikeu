use askama::Template;
use axum::{
    Form,
    extract::{Multipart, State},
    http::StatusCode,
    response::{Html, Redirect},
};
use calamine::{DataRef, Reader, Xlsx};
use serde::{Deserialize, Serialize};
use sqlx::SqliteConnection;
use std::{collections::HashSet, io::Cursor};
use tower_sessions::Session;

use crate::{
    App, Error, Result,
    auth::{User, check_csrf, csrf},
    page,
    records::audit,
};

const LIMIT: usize = 200;
const HEADER: [&str; 5] = ["admission_no", "assessment", "subject", "score", "maximum"];

#[derive(Clone, Deserialize, Serialize)]
struct Row {
    admission: String,
    assessment: String,
    subject: String,
    score: i64,
    maximum: i64,
}
#[derive(Deserialize, Serialize)]
struct Draft {
    nonce: String,
    expires: i64,
    rows: Vec<Row>,
}
#[derive(Template)]
#[template(path = "marks-preview.html")]
struct Preview {
    csrf: String,
    nonce: String,
    rows: Vec<Row>,
}

fn workbook(bytes: &[u8]) -> Result<Vec<Row>> {
    let invalid = || {
        Error::Invalid(
            "Upload an .xlsx workbook with one sheet, the required headings and up to 200 marks.",
        )
    };
    if bytes.len() > 512 * 1024 {
        return Err(invalid());
    }
    let mut zip = zip::ZipArchive::new(Cursor::new(bytes)).map_err(|_| invalid())?;
    if zip.len() > 48 {
        return Err(invalid());
    }
    let mut expanded = 0u64;
    for index in 0..zip.len() {
        let file = zip.by_index_raw(index).map_err(|_| invalid())?;
        expanded = expanded.saturating_add(file.size());
        if expanded > 4 * 1024 * 1024 {
            return Err(invalid());
        }
    }

    let mut workbook: Xlsx<_> =
        calamine::open_workbook_from_rs(Cursor::new(bytes)).map_err(|_| invalid())?;
    let names = workbook.sheet_names();
    if names.len() != 1 {
        return Err(invalid());
    }
    let mut reader = workbook
        .worksheet_cells_reader(&names[0])
        .map_err(|_| invalid())?;
    let mut cells = vec![vec![String::new(); HEADER.len()]; LIMIT + 1];
    let mut occupied = HashSet::new();
    while let Some(cell) = reader.next_cell().map_err(|_| invalid())? {
        if matches!(cell.get_value(), DataRef::Empty) {
            continue;
        }
        let (row, column) = cell.get_position();
        let (row, column) = (row as usize, column as usize);
        if row > LIMIT || column >= HEADER.len() || !occupied.insert((row, column)) {
            return Err(invalid());
        }
        let value = match cell.get_value() {
            DataRef::SharedString(s) => s.trim().to_owned(),
            DataRef::String(s) => s.trim().to_owned(),
            DataRef::Float(n)
                if row > 0 && column >= 3 && (0.0..=1000.0).contains(n) && n.fract() == 0.0 =>
            {
                format!("{n:.0}")
            }
            DataRef::Int(n) if row > 0 && column >= 3 => n.to_string(),
            _ => return Err(invalid()),
        };
        if value.chars().count() > 120 || value.contains('\0') {
            return Err(invalid());
        }
        cells[row][column] = value;
    }
    if cells[0] != HEADER {
        return Err(invalid());
    }
    let mut rows = Vec::new();
    let mut seen = HashSet::new();
    for row in cells
        .into_iter()
        .skip(1)
        .filter(|row| row.iter().any(|cell| !cell.is_empty()))
    {
        let [admission, assessment, subject, score, maximum]: [String; 5] =
            row.try_into().map_err(|_| invalid())?;
        if [&admission, &assessment, &subject]
            .iter()
            .any(|text| text.is_empty())
        {
            return Err(invalid());
        }
        let score: i64 = score.parse().map_err(|_| invalid())?;
        let maximum: i64 = maximum.parse().map_err(|_| invalid())?;
        if !(1..=1000).contains(&maximum) || !(0..=maximum).contains(&score) {
            return Err(invalid());
        }
        if !seen.insert((
            admission.clone(),
            assessment.to_ascii_lowercase(),
            subject.to_ascii_lowercase(),
        )) {
            return Err(Error::Invalid(
                "The workbook repeats a student, assessment and subject.",
            ));
        }
        rows.push(Row {
            admission,
            assessment,
            subject,
            score,
            maximum,
        });
    }
    if rows.is_empty() {
        return Err(invalid());
    }
    Ok(rows)
}

async fn student_id(connection: &mut SqliteConnection, row: &Row) -> Result<i64> {
    sqlx::query_scalar!("SELECT id FROM students WHERE admission=?", row.admission)
        .fetch_optional(connection)
        .await?
        .flatten()
        .ok_or(Error::Invalid(
            "An admission number in the workbook is not in the roster.",
        ))
}

async fn verify_row(connection: &mut SqliteConnection, id: i64, row: &Row) -> Result<bool> {
    let existing = sqlx::query_as::<_,(i64,i64)>(
        "SELECT score,maximum FROM marks WHERE student_id=? AND assessment=? COLLATE NOCASE AND subject=? COLLATE NOCASE")
        .bind(id).bind(&row.assessment).bind(&row.subject).fetch_optional(connection).await?;
    match existing {
        Some(values) if values != (row.score, row.maximum) => Err(Error::Status(
            StatusCode::CONFLICT,
            "A mark conflicts with an existing result. Review the workbook and existing record before importing.",
        )),
        Some(_) => Ok(false),
        None => Ok(true),
    }
}

pub async fn preview(
    State(app): State<App>,
    user: User,
    session: Session,
    mut form: Multipart,
) -> Result<Html<String>> {
    user.admin()?;
    let mut evidence = None;
    let mut file = None;
    let invalid = || Error::Invalid("Choose an .xlsx file and submit the import form.");
    while let Some(field) = form.next_field().await.map_err(|_| invalid())? {
        match field.name() {
            Some("csrf") if evidence.is_none() => {
                evidence = Some(field.text().await.map_err(|_| invalid())?)
            }
            Some("workbook") if file.is_none() => {
                file = Some(field.bytes().await.map_err(|_| invalid())?)
            }
            _ => return Err(invalid()),
        }
    }
    check_csrf(&session, evidence.as_deref().unwrap_or_default()).await?;
    session.remove::<Draft>("marks_import").await?;
    let file = file.ok_or_else(invalid)?;
    let rows = tokio::task::spawn_blocking(move || workbook(&file))
        .await
        .map_err(|_| Error::Internal)??;
    let mut conn = app.db.acquire().await?;
    let mut new = Vec::new();
    for row in rows {
        let id = student_id(&mut conn, &row).await?;
        if verify_row(&mut conn, id, &row).await? {
            new.push(row);
        }
    }
    if new.is_empty() {
        return Err(Error::Invalid(
            "All workbook marks already exist. No changes are needed.",
        ));
    }
    let nonce = uuid::Uuid::new_v4().simple().to_string();
    session
        .insert(
            "marks_import",
            Draft {
                nonce: nonce.clone(),
                expires: time::OffsetDateTime::now_utc().unix_timestamp() + 600,
                rows: new.clone(),
            },
        )
        .await?;
    page(Preview {
        csrf: csrf(&session).await?,
        nonce,
        rows: new,
    })
}

#[derive(Deserialize)]
pub struct ImportForm {
    csrf: String,
    nonce: String,
}
pub async fn confirm(
    State(app): State<App>,
    user: User,
    session: Session,
    Form(form): Form<ImportForm>,
) -> Result<Redirect> {
    user.admin()?;
    check_csrf(&session, &form.csrf).await?;
    let draft: Draft = session
        .get("marks_import")
        .await?
        .ok_or(Error::Invalid("Preview the workbook first."))?;
    if draft.nonce != form.nonce || draft.expires < time::OffsetDateTime::now_utc().unix_timestamp()
    {
        return Err(Error::Invalid(
            "Preview the workbook again before confirming.",
        ));
    }
    let mut tx = app.db.begin_with("BEGIN IMMEDIATE").await?;
    for row in draft.rows {
        let id = student_id(&mut tx, &row).await?;
        if !verify_row(&mut tx, id, &row).await? {
            continue;
        }
        let result=sqlx::query("INSERT INTO marks(student_id,assessment,subject,score,maximum,released,source) VALUES (?,?,?,?,?,1,'Reviewed Excel import')")
            .bind(id).bind(row.assessment).bind(row.subject).bind(row.score).bind(row.maximum).execute(&mut *tx).await?;
        audit(
            &mut tx,
            user.id,
            "release_excel_mark",
            result.last_insert_rowid(),
        )
        .await?;
    }
    tx.commit().await?;
    session.remove::<Draft>("marks_import").await?;
    Ok(Redirect::to("/dashboard"))
}
