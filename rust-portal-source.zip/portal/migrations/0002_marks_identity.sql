CREATE UNIQUE INDEX marks_identity ON marks(student_id, assessment COLLATE NOCASE, subject COLLATE NOCASE);
