use super::*;
use axum::{
    body::{Body, to_bytes},
    http::{Request, header},
};
use tower::ServiceExt;

struct Client {
    router: Router,
    cookie: String,
}
impl Client {
    fn new(router: &Router) -> Self {
        Self {
            router: router.clone(),
            cookie: String::new(),
        }
    }
    async fn request(
        &mut self,
        method: Method,
        path: &str,
        data: impl Into<Body>,
        content_type: &str,
    ) -> (StatusCode, String) {
        let mut request = Request::builder()
            .method(method)
            .uri(path)
            .header(header::CONTENT_TYPE, content_type);
        if !self.cookie.is_empty() {
            request = request.header(header::COOKIE, &self.cookie);
        }
        let response = self
            .router
            .clone()
            .oneshot(request.body(data.into()).unwrap())
            .await
            .unwrap();
        if let Some(cookie) = response.headers().get(header::SET_COOKIE) {
            let cookie = cookie.to_str().unwrap();
            assert!(cookie.contains("HttpOnly"));
            self.cookie = cookie.split(';').next().unwrap().to_owned();
        }
        let status = response.status();
        let body = to_bytes(response.into_body(), 3 * 1024 * 1024)
            .await
            .unwrap();
        (status, String::from_utf8(body.to_vec()).unwrap())
    }
    async fn get(&mut self, path: &str) -> (StatusCode, String) {
        self.request(Method::GET, path, Body::empty(), "text/plain")
            .await
    }
    async fn form(&mut self, path: &str, data: String) -> StatusCode {
        self.request(
            Method::POST,
            path,
            data,
            "application/x-www-form-urlencoded",
        )
        .await
        .0
    }
    async fn login(&mut self, role: &str, login: &str, password: &str) -> StatusCode {
        let (_, page) = self.get("/login").await;
        self.form(
            "/login",
            format!(
                "role={role}&login={login}&password={password}&csrf={}",
                token(&page)
            ),
        )
        .await
    }
}

fn token(page: &str) -> &str {
    page.split_once("name=\"csrf\" value=\"")
        .unwrap()
        .1
        .split('"')
        .next()
        .unwrap()
}

async fn setup() -> (Router, SqlitePool) {
    let db = database("sqlite::memory:".parse().unwrap()).await.unwrap();
    seed::bootstrap(&db, true, "admin-test-password", Some("demo-test-password"))
        .await
        .unwrap();
    let app = App {
        db: db.clone(),
        demo: true,
        dummy_hash: auth::hash("dummy-unused-password").unwrap(),
        password_slots: Arc::new(Semaphore::new(2)),
    };
    (
        app_router(
            app,
            false,
            HeaderValue::from_static("https://kasikeu.vercel.app"),
            true,
        )
        .await
        .unwrap(),
        db,
    )
}

#[tokio::test]
async fn only_admin_can_publish_and_documents_are_public() {
    let (router, db) = setup().await;
    let mut visitor = Client::new(&router);
    let (_, public) = visitor.get("/api/public/notice").await;
    let json: serde_json::Value = serde_json::from_str(&public).unwrap();
    assert_eq!(json["demo"], true);
    assert_eq!(json["data"]["title"], "Demo reporting notice");
    assert_eq!(visitor.get("/admin").await.0, StatusCode::SEE_OTHER);
    assert_eq!(
        visitor.get("/api/public/students").await.0,
        StatusCode::NOT_FOUND
    );

    let mut student = Client::new(&router);
    assert_eq!(
        student
            .login("student", "DEMO-001", "demo-test-password")
            .await,
        StatusCode::SEE_OTHER
    );
    assert_eq!(student.get("/admin").await.0, StatusCode::FORBIDDEN);
    assert_eq!(student.form("/admin/notice","csrf=x&title=Bad&reporting_date=2027-02-01&arrival_window=Morning&message=Demo&document_id=0".into()).await,StatusCode::FORBIDDEN);

    let mut admin = Client::new(&router);
    assert_eq!(
        admin
            .login("admin", "admin%40example.test", "admin-test-password")
            .await,
        StatusCode::SEE_OTHER
    );
    let (status, page) = admin.get("/admin").await;
    assert_eq!(status, StatusCode::OK);
    let csrf = token(&page);
    let form = |token: &str, id| {
        format!(
            "csrf={token}&title=Approved+demo&reporting_date=2027-02-01&arrival_window=Morning&message=Demo&document_id={id}"
        )
    };
    assert_eq!(
        admin.form("/admin/notice", form("wrong", 0)).await,
        StatusCode::FORBIDDEN
    );
    let multipart = |pdf: &str| {
        format!(
            "--test\r\nContent-Disposition: form-data; name=\"csrf\"\r\n\r\n{csrf}\r\n--test\r\nContent-Disposition: form-data; name=\"title\"\r\n\r\nDemo instructions\r\n--test\r\nContent-Disposition: form-data; name=\"category\"\r\n\r\njoining\r\n--test\r\nContent-Disposition: form-data; name=\"pdf\"; filename=\"demo.pdf\"\r\nContent-Type: application/pdf\r\n\r\n{pdf}\r\n--test--\r\n"
        )
    };
    let pdf = "%PDF-1.4\n%%EOF\n";
    assert_eq!(
        admin
            .request(
                Method::POST,
                "/admin/documents",
                multipart("fake"),
                "multipart/form-data; boundary=test"
            )
            .await
            .0,
        StatusCode::BAD_REQUEST
    );
    assert_eq!(
        admin
            .request(
                Method::POST,
                "/admin/documents",
                multipart(pdf),
                "multipart/form-data; boundary=test"
            )
            .await
            .0,
        StatusCode::SEE_OTHER
    );
    assert_eq!(
        admin.form("/admin/notice", form(csrf, 1)).await,
        StatusCode::SEE_OTHER
    );
    let (_, updated) = visitor.get("/api/public/notice").await;
    assert!(updated.contains("Approved demo") && updated.contains("\"document_id\":1"));
    assert!(
        visitor
            .get("/api/public/documents")
            .await
            .1
            .contains("Demo instructions")
    );
    assert_eq!(visitor.get("/api/public/documents/1").await.1, pdf);
    assert_eq!(
        admin
            .form("/admin/documents/1/remove", format!("csrf={csrf}"))
            .await,
        StatusCode::SEE_OTHER
    );
    assert_eq!(
        visitor.get("/api/public/documents/1").await.0,
        StatusCode::NOT_FOUND
    );
    assert!(
        visitor
            .get("/api/public/notice")
            .await
            .1
            .contains("\"document_id\":null")
    );
    assert_eq!(
        sqlx::query_scalar::<_, i64>("SELECT count(*) FROM audit")
            .fetch_one(&db)
            .await
            .unwrap(),
        3
    );
}

#[tokio::test]
async fn checks_guardian_teacher_and_support_scopes() {
    let (router, db) = setup().await;
    for (role, login) in [
        ("student", "DEMO-001"),
        ("guardian", "guardian%40example.test"),
        ("teacher", "teacher%40example.test"),
    ] {
        let mut client = Client::new(&router);
        assert_eq!(
            client.login(role, login, "demo-test-password").await,
            StatusCode::SEE_OTHER
        );
        let (_, body) = client.get("/dashboard?student=1").await;
        assert!(
            body.contains("Mathematics")
                && body.contains("Demo shared follow-up")
                && body.contains("KES 1500.00")
        );
        for restricted in [
            "Biology",
            "Confidential sample note",
            "Draft incident",
            "Demo Student Two",
        ] {
            assert!(!body.contains(restricted));
        }
        assert_eq!(
            client.get("/dashboard?student=2").await.0,
            StatusCode::NOT_FOUND
        );
        assert_eq!(
            client
                .form(
                    "/dashboard/fees",
                    "student=1&csrf=bad&description=X&amount_cents=100&reference=REF".into()
                )
                .await,
            StatusCode::FORBIDDEN
        );
        if role == "teacher" {
            sqlx::query("UPDATE accounts SET posting_verified=0 WHERE role='teacher'")
                .execute(&db)
                .await
                .unwrap();
            assert_eq!(client.get("/dashboard").await.0, StatusCode::SEE_OTHER);
            assert_eq!(
                client.login(role, login, "demo-test-password").await,
                StatusCode::UNAUTHORIZED
            );
        }
    }
    let mut bursar = Client::new(&router);
    assert_eq!(
        bursar
            .login("support", "bursar%40example.test", "demo-test-password")
            .await,
        StatusCode::SEE_OTHER
    );
    let (_, body) = bursar.get("/dashboard?student=1").await;
    assert!(
        body.contains("Record fee entry")
            && !body.contains("Mathematics")
            && !body.contains("Demo shared follow-up")
    );
    let csrf = token(&body);
    let payment =
        format!("student=1&csrf={csrf}&description=Payment&amount_cents=-100&reference=NEW123");
    assert_eq!(
        bursar.form("/dashboard/fees", payment.clone()).await,
        StatusCode::SEE_OTHER
    );
    assert_eq!(
        bursar.form("/dashboard/fees", payment).await,
        StatusCode::CONFLICT
    );
    assert!(
        bursar
            .get("/dashboard?student=1")
            .await
            .1
            .contains("KES 1499.00")
    );
    assert_eq!(
        bursar
            .form(
                "/dashboard/discipline",
                format!("student=1&csrf={csrf}&summary=Test&internal_note=Test")
            )
            .await,
        StatusCode::FORBIDDEN
    );
}

#[tokio::test]
async fn cors_only_exposes_public_data_to_configured_origins() {
    let (router, _) = setup().await;
    for (endpoint, origin, allowed) in [
        ("/api/public/notice", "https://kasikeu.vercel.app", true),
        ("/api/public/documents", "http://localhost:8000", true),
        (
            "/api/public/notice",
            "https://kasikeu.vercel.app.example.test",
            false,
        ),
        ("/dashboard", "https://kasikeu.vercel.app", false),
    ] {
        let response = router
            .clone()
            .oneshot(
                Request::builder()
                    .uri(endpoint)
                    .header(header::ORIGIN, origin)
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(
            response
                .headers()
                .contains_key(header::ACCESS_CONTROL_ALLOW_ORIGIN),
            allowed
        );
        assert!(
            !response
                .headers()
                .contains_key(header::ACCESS_CONTROL_ALLOW_CREDENTIALS)
        );
    }
}

#[tokio::test]
async fn excel_preview_releases_only_reviewed_valid_marks() {
    let (router, db) = setup().await;
    let mut admin = Client::new(&router);
    let mut viewer = Client::new(&router);
    assert_eq!(
        admin
            .login("admin", "admin%40example.test", "admin-test-password")
            .await,
        StatusCode::SEE_OTHER
    );
    assert_eq!(
        viewer
            .login("student", "DEMO-001", "demo-test-password")
            .await,
        StatusCode::SEE_OTHER
    );
    let csrf = token(&admin.get("/admin").await.1).to_owned();
    let upload = |file: &[u8]| {
        let mut body = format!("--marks\r\nContent-Disposition: form-data; name=\"csrf\"\r\n\r\n{csrf}\r\n--marks\r\nContent-Disposition: form-data; name=\"workbook\"; filename=\"grades.xlsx\"\r\nContent-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet\r\n\r\n").into_bytes();
        body.extend_from_slice(file);
        body.extend_from_slice(b"\r\n--marks--\r\n");
        body
    };
    let content_type = "multipart/form-data; boundary=marks";
    for file in [
        include_bytes!("../fixtures/unknown.xlsx").as_slice(),
        include_bytes!("../fixtures/duplicate.xlsx").as_slice(),
    ] {
        assert_eq!(
            admin
                .request(
                    Method::POST,
                    "/admin/marks/preview",
                    upload(file),
                    content_type
                )
                .await
                .0,
            StatusCode::BAD_REQUEST
        );
    }
    let (status, preview) = admin
        .request(
            Method::POST,
            "/admin/marks/preview",
            upload(include_bytes!("../fixtures/valid.xlsx")),
            content_type,
        )
        .await;
    assert_eq!(status, StatusCode::OK);
    assert!(
        preview.contains("DEMO-001") && preview.contains("English") && preview.contains("73/100")
    );
    assert!(!viewer.get("/dashboard").await.1.contains("English"));
    let nonce = preview
        .split_once("name=\"nonce\" value=\"")
        .unwrap()
        .1
        .split('"')
        .next()
        .unwrap();
    let form = format!("csrf={csrf}&nonce={nonce}");
    assert_eq!(
        admin.form("/admin/marks/confirm", form.clone()).await,
        StatusCode::SEE_OTHER
    );
    assert_eq!(
        admin.form("/admin/marks/confirm", form).await,
        StatusCode::BAD_REQUEST
    );
    let body = viewer.get("/dashboard").await.1;
    assert!(body.contains("English") && body.contains("73/100") && !body.contains("Geography"));
    assert_eq!(
        admin
            .request(
                Method::POST,
                "/admin/marks/preview",
                upload(include_bytes!("../fixtures/conflict.xlsx")),
                content_type
            )
            .await
            .0,
        StatusCode::CONFLICT
    );
    let changes: i64 =
        sqlx::query_scalar("SELECT count(*) FROM audit WHERE action='release_excel_mark'")
            .fetch_one(&db)
            .await
            .unwrap();
    assert_eq!(changes, 2);
}
