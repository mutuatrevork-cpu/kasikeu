CREATE TABLE accounts (
  id INTEGER PRIMARY KEY,
  role TEXT NOT NULL CHECK(role IN ('admin','teacher','student','guardian','support')),
  login TEXT NOT NULL COLLATE NOCASE,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  tsc_verified INTEGER NOT NULL DEFAULT 0 CHECK(tsc_verified IN (0,1)),
  posting_verified INTEGER NOT NULL DEFAULT 0 CHECK(posting_verified IN (0,1)),
  UNIQUE(role, login)
);
CREATE TABLE students (
  id INTEGER PRIMARY KEY,
  account_id INTEGER NOT NULL UNIQUE REFERENCES accounts(id),
  admission TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  class TEXT NOT NULL
);
CREATE TABLE guardian_links (
  account_id INTEGER NOT NULL REFERENCES accounts(id),
  student_id INTEGER NOT NULL REFERENCES students(id),
  PRIMARY KEY(account_id, student_id)
);
CREATE TABLE teacher_assignments (
  account_id INTEGER NOT NULL REFERENCES accounts(id),
  student_id INTEGER NOT NULL REFERENCES students(id),
  PRIMARY KEY(account_id, student_id)
);
CREATE TABLE support_permissions (
  account_id INTEGER NOT NULL REFERENCES accounts(id),
  permission TEXT NOT NULL CHECK(permission IN ('fees','discipline')),
  PRIMARY KEY(account_id, permission)
);
CREATE TABLE marks (
  id INTEGER PRIMARY KEY,
  student_id INTEGER NOT NULL REFERENCES students(id),
  assessment TEXT NOT NULL,
  subject TEXT NOT NULL,
  score INTEGER NOT NULL,
  maximum INTEGER NOT NULL CHECK(maximum > 0 AND score BETWEEN 0 AND maximum),
  released INTEGER NOT NULL CHECK(released IN (0,1)),
  source TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE fee_entries (
  id INTEGER PRIMARY KEY,
  student_id INTEGER NOT NULL REFERENCES students(id),
  description TEXT NOT NULL,
  amount_cents INTEGER NOT NULL,
  reference TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE discipline (
  id INTEGER PRIMARY KEY,
  student_id INTEGER NOT NULL REFERENCES students(id),
  summary TEXT NOT NULL,
  internal_note TEXT NOT NULL DEFAULT '',
  shared INTEGER NOT NULL DEFAULT 0 CHECK(shared IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE documents (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL CHECK(category IN ('joining','fees','checklist','learning')),
  pdf BLOB NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE notice (
  id INTEGER PRIMARY KEY CHECK(id=1),
  title TEXT NOT NULL,
  reporting_date TEXT NOT NULL,
  arrival_window TEXT NOT NULL,
  message TEXT NOT NULL,
  document_id INTEGER REFERENCES documents(id),
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE audit (
  id INTEGER PRIMARY KEY,
  actor INTEGER NOT NULL REFERENCES accounts(id),
  action TEXT NOT NULL,
  target INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
