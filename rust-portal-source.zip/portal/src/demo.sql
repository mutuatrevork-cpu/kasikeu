INSERT INTO students (id,account_id,admission,name,class) VALUES
            (1,2,'DEMO-001','Demo Student One','Grade 10 STEM'),
            (2,3,'DEMO-002','Demo Student Two','Grade 10 Social Sciences');
            INSERT INTO guardian_links VALUES (4,1);
            INSERT INTO teacher_assignments VALUES (5,1);
            INSERT INTO support_permissions VALUES (6,'fees');
            INSERT INTO marks (student_id,assessment,subject,score,maximum,released,source) VALUES
            (1,'Term 1 practice assessment','Mathematics',64,100,1,'Fictional sample'),
            (1,'Term 1 draft assessment','Biology',82,100,0,'Fictional sample'),
            (2,'Term 1 practice assessment','Geography',71,100,1,'Fictional sample');
            INSERT INTO fee_entries(student_id,description,amount_cents,reference) VALUES
            (1,'Demo charge',250000,'DEMO-CHARGE'),(1,'Demo payment',-100000,'DEMO-RECEIPT');
            INSERT INTO discipline(student_id,summary,internal_note,shared) VALUES
            (1,'Demo shared follow-up','Confidential sample note',1),
            (1,'Draft incident','Confidential sample note',0);
            INSERT INTO notice(id,title,reporting_date,arrival_window,message) VALUES
            (1,'Demo reporting notice','2027-01-14','08:00 to 11:30 EAT','Fictional example for testing.');
