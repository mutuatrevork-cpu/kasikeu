# Kasikeu portal demo

This Rust service runs alongside the public Vercel website. Demo mode seeds fictional records at startup and uses a separate SQLite file from regular mode. No real school records belong in the free demo.

## Run the demo on this computer

Use stable Rust 1.100 and Node.js 20 or newer. From the repository root:

```bash
cd portal
export PORTAL_DEMO=1 PORTAL_LOCAL_HTTP=1 PORT=8080
export PORTAL_ADMIN_PASSWORD="$(openssl rand -hex 24)"
export PORTAL_DEMO_PASSWORD="$(openssl rand -hex 24)"
cargo test --locked
cargo run --locked
```

Open [the local portal](http://localhost:8080/login). For a full public-site preview, run these commands from the repository root in another terminal:

```bash
PORTAL_ORIGIN=http://localhost:8080 PORTAL_ALLOW_DEMO=1 node build.mjs
python -m http.server 8000 --directory dist
```

The basic Python server serves inner pages at their `.html` filenames. The production Vercel configuration keeps clean URLs.

| Account type | Demo login | Password variable |
|---|---|---|
| Administrator | `admin@example.test` | `PORTAL_ADMIN_PASSWORD` |
| Student | `DEMO-001` or `DEMO-002` | `PORTAL_DEMO_PASSWORD` |
| Parent or guardian | `guardian@example.test` | `PORTAL_DEMO_PASSWORD` |
| Teacher | `teacher@example.test` | `PORTAL_DEMO_PASSWORD` |
| Support staff | `bursar@example.test` | `PORTAL_DEMO_PASSWORD` |

The guardian and teacher are linked to DEMO-001. The bursar has finance permissions. Passwords seed a new database, and changing the variables does not rotate accounts in an existing database.

## Publish a notice and PDF

In the portal's **Public notices and documents** screen, publish an approved PDF in the **Joining instructions** category. Select it when publishing the reporting notice. Other PDF categories appear on the corresponding public Joining or Resources page. The portal keeps up to 20 PDFs in SQLite, with a 2 MiB limit per document. Unpublishing a PDF removes it from downloads and clears its link on the reporting notice.

The Vercel build uses the `PORTAL_ORIGIN` environment variable for the public API and login links. Set `PORTAL_ALLOW_DEMO=1` only in an isolated Vercel preview to display fictional notices and downloads. Leave `PORTAL_ORIGIN` unset on production until a production portal is available. The official Zeraki shortcuts remain available with or without a portal origin configured.

## Set up Render

Use the repository's `render.yaml` Blueprint with the demo branch selected. Enter distinct random values for `PORTAL_ADMIN_PASSWORD` and `PORTAL_DEMO_PASSWORD` as Render secrets. The demo binds to Render's supplied port and exposes `/health`. Use the HTTPS hostname Render assigns as `PORTAL_ORIGIN` in a Vercel preview. Set the portal's `PUBLIC_SITE_ORIGIN` in Render to that preview's exact origin to allow cross-origin notice and PDF listings. The default is the existing Vercel production origin.

Render's free filesystem is ephemeral. The demo database and uploaded examples can reset after restarts or sleep. See [Render's free-tier documentation](https://render.com/docs/free) and [Blueprint setup](https://render.com/tutorials/firstdeploy/create-a-blueprint).

## Records and remaining work

- Students can read their own released marks, statement and shared discipline summaries. Guardians can read linked student records. Teachers need both verification flags and see assigned students. Finance and discipline writes require distinct permissions. Public endpoints return only notices and approved school PDFs.
- Fee entries use signed integer cents, require a unique transaction reference, and can be corrected with a separate reversing entry. Discipline summaries are private by default. Internal notes are restricted to authorised discipline staff and admins.
- For Excel backup imports, use one sheet with the columns `admission_no,assessment,subject,score,maximum`. Keep admission numbers as text. Include the year, term and exam in each assessment label. Admin preview rejects unknown admissions, duplicate rows and conflicting existing marks. Confirm publishes new rows in one transaction. Fictional examples are in `fixtures/`.
- Zeraki Analytics is the intended marks-only source. Automated sync depends on Zeraki providing a supported school-authorised integration and matching identifiers. This release has no vendor connector.
- Production work includes admin-managed account invitations and guardian links, TSC and posting evidence workflows, password recovery and staff MFA, class materials, private document storage, retention controls, monitored backups and a restoration test. The public-site CMS continues to handle school pages and the staff directory.
